 [![Download Apk](https://images.microbadger.com/badges/version/runmymind/docker-android-sdk.svg)](https://github.com/rizwansoaib/Android-Library-Management/raw/master/LMS.apk "Download APK now") [![Build Status](https://semaphoreapp.com/api/v1/projects/d4cca506-99be-44d2-b19e-176f36ec8cf1/128505/badge.svg)](https://github.com/rizwansoaib/Android-Library-Management)  [![GPLv3 license](https://img.shields.io/badge/License-GPLv3-blue.svg)](http://perso.crans.org/besson/LICENSE.html) [![star this repo](http://githubbadges.com/star.svg?user=rizwansoaib&repo=Android-Library-Management)](https://github.com/rizwansoaib/Android-Library-Management)
[![fork this repo](http://githubbadges.com/fork.svg?user=rizwansoaib&repo=Android-Library-Management)](http://github.com/rizwansoaib/Android-Library-Management/fork) [![HitCount](http://hits.dwyl.io/rizwansoaib/Android-Library-Management.svg)](http://hits.dwyl.io/rizwansoaib/Android-Library-Management)
 
 # ANDROID LIBRARY MANAGEMENT SYSTEM 
 
 ![tf](https://user-images.githubusercontent.com/29729380/50545488-4dd63b00-0c3b-11e9-82cc-c671f1e070b8.gif)![output_amrlrj](https://user-images.githubusercontent.com/29729380/50546540-02c62300-0c4f-11e9-8af5-b66e1bb92055.gif)
                                                     ![output_k7hkqi](https://user-images.githubusercontent.com/29729380/50546545-415bdd80-0c4f-11e9-83a0-ade901e95cb6.gif)
                                                    ![output_7vy2od](https://user-images.githubusercontent.com/29729380/50546559-8aac2d00-0c4f-11e9-970c-946254e9dc3f.gif)

Android Library Management System is an android app which helps to manage library through an android smartphone.


## Installation

### [Click Here To Download APK](https://github.com/rizwansoaib/Android-Library-Management/raw/master/LMS.apk)

## Features

1. Login and Sign up
2. Scan Student id and book id via Barcode or QrCode
3. See Student details and history
4. Add new Book section
5. Check Book Availibility





## Contributing 


### Step 1

- **Option 1**
    - 🍴 Fork this repo!

- **Option 2**
    - 👯 Clone this repo to your local machine using `https://github.com/rizwansoaib/Android-Library-Management.git`

### Step 2

- **HACK AWAY!** 🔨🔨🔨

### Step 3

- 🔃 Create a new pull request using <a href="https://github.com/rizwansoaib/Android-Library-Management/compare/" target="_blank">`https://github.com/rizwansoaib/Android-Library-Management/compare/`</a>.

## Team





| <a href="https://github.com/rizwansoaib" target="_blank">**RIZWAN AHMAD**</a> | <a href="https://github.com/subahanii" target="_blank">**GHULAM MOHIYUDDIN**</a> |
| :---: |:---:| 
| [![RIZWAN AHMAD](https://avatars1.githubusercontent.com/u/29729380?s=200&v=4)](https://github.com/rizwansoaib)    | [![GHULAM MOHIYUDDIN](https://avatars1.githubusercontent.com/u/23014491?s=200&v=4)](https://github.com/subahanii) | 
| <a href="https://github.com/rizwansoaib" target="_blank">`github.com/rizwansoaib`</a> | <a href="https://github.com/subahanii" target="_blank">`github.com/subahanii`</a> | 
